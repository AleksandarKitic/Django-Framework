from django.db import models
# from django.forms import ModelForm

# Create your models here
TITLE_CHOICE = [
    ('MR', 'Mr.'),
    ('MRS', 'Mrs.'),
    ('MS', 'Ms.'),
]


class Author(models.Model):
    name = models.CharField(max_length=120)
    title = models.CharField(max_length=3, choices=TITLE_CHOICE)
    date = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return self.name


class Blog(models.Model):
    title = models.TextField()
    time = models.DateTimeField(auto_now=False)
    text = models.TextField()
