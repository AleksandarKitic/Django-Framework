from django.urls import path
from . import views

urlpatterns = [
    path('', views.frontend, name='frontend'),  # In first string we put empty field to open first page when you runsrv
    path('contact/', views.contact, name='contact'),     # Second page
    path('about/', views.about, name='about'),   # Third page
]
