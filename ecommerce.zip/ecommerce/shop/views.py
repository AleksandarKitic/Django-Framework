from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.

def frontend(request, *args, **kwargs):
    print(args, kwargs)
    print(request.user)
    return render(request, 'index.html', {})    # , {'name': 'Django Developer'}

def contact(request, *args, **kwargs):
    print(args, kwargs)
    print(request.user)
    return render(request, 'contact.html', {})

def about(request, *args, **kwargs):
    print(args, kwargs)
    print(request.user)
    my_contents = {
        'my_text': 'I am Django Senior Developer',
        'numbers': 1997,
        'my_list': [1997, 1994, 1995, 2000, 1972, 1970, 1942]
    }
    for item in [1997, 1994, 1995]:
        my_contents['Item1'] = item

    return render(request, 'about.html', my_contents)
