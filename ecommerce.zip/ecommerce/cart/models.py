from django.db import models

# Create your models here.

class Cart(models.Model):
    title = models.TextField()
    quantity = models.TextField()
    price = models.TextField()
