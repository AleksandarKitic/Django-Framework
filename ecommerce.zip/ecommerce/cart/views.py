from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

# Create your views here.


def index(request):
    request = 'Here is the Cart of Products'
    return HttpResponse(request)

