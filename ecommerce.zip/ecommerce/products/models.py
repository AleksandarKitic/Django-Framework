from django.db import models

# When you change here in models or add something new var, you must go in DB to change it


class Products(models.Model):
    title = models.CharField(max_length=120)    # max_length is required
    description = models.TextField(blank=True, null=False)
    price = models.FloatField()  # decimal_places , max_digits is required
    featured = models.BooleanField(null=True, default=True)  # null = True, default = True
