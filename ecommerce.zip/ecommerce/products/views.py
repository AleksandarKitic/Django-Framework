from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    request = 'Here is the Products'
    return HttpResponse(request)

def product_detail_view(request):
    return render(request, 'product/detail.html', {})
