from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


def index(request):
    request = 'Here is the Profiles'
    return HttpResponse(request)
