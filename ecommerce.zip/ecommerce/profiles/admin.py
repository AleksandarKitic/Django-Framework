from django.contrib import admin
from .models import Profiles
# Register your models here.

admin.site.register(Profiles)
