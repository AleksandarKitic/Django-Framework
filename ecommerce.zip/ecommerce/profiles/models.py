from django.db import models

# Create your models here.
class Profiles(models.Model):
    username = models.TextField()
    description = models.TextField()
    image = models.TextField()
    time = models.TextField()
